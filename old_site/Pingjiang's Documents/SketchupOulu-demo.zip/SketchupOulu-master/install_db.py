import variables
from models.user import User
from models.scenario import Scenario
from models.custom_model import CustomModel
from models.comment import CommentTopic
#from models.comment import Comment

variables.db.create_all()