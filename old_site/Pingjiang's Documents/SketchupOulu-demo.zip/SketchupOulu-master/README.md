# SketchupOulu

### Python version: latest, preferable Python 3.4

The code structure:

  - index.html - Main Web pagesite, entrance.
  - js folder - contain all the javascript code related with 3D model display, control and so on
    - 3d.js - contain all the procc after the windows is ready
    - ColladaLoader.js - used for automatically load 3d model file
    - Communication.js - how the client communication with server to get information and data
    - Detector.js - Used for detect whether the broswer support 3D display
    - three.min.js - main library for 3D frunction
  - collada folder - contain all the image used for UI, the 3D mdoel format is dae.
  - lib folder - contain js file used for UI layout and animation effects
  - style.css - layout file for UI

### Data base
    
  - 
  
### Definition of Terms

  - Scenario: 3D model of a big area
  - Base scenario: public scenario from moderators so other users can clone and edit to the model
  - Custom model: a 3D model of a building

maybe we need to discuss later to decide which term to be used, for example, it we say "project", we don't know it means one specific design for a big area or one design project which contain several users' designs.
