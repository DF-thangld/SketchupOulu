{

    "metadata" :
    {
        "formatVersion" : 3.1,
        "sourceFile"    : "male02.obj",
        "generatedBy"   : "OBJConverter",
        "vertices"      : 2746,
        "faces"         : 5004,
        "normals"       : 2769,
        "uvs"           : 3275,
        "materials"     : 5
    },

    "materials": [	{
	"DbgColor" : 15658734,
	"DbgIndex" : 0,
	"DbgName" : "male-02-1noCullingID_male-02-1noCulling.JP",
	"colorDiffuse" : [0.64, 0.64, 0.64],
	"colorSpecular" : [0.165, 0.165, 0.165],
	"illumination" : 2,
	"mapDiffuse" : "male-02-1noCulling.JPG",
	"opticalDensity" : 1.0,
	"specularCoef" : 154.901961,
	"opacity" : 1.0
	},

	{
	"DbgColor" : 15597568,
	"DbgIndex" : 1,
	"DbgName" : "orig_02_-_Defaul1noCu_orig_02_-_Defaul1noCu",
	"colorDiffuse" : [0.64, 0.64, 0.64],
	"colorSpecular" : [0.165, 0.165, 0.165],
	"illumination" : 2,
	"mapDiffuse" : "orig_02_-_Defaul1noCulling.JPG",
	"opticalDensity" : 1.0,
	"specularCoef" : 154.901961,
	"opacity" : 1.0
	},

	{
	"DbgColor" : 60928,
	"DbgIndex" : 2,
	"DbgName" : "FrontColorNoCullingID_orig_02_-_Defaul1noCu",
	"colorDiffuse" : [0.8, 0.8, 0.8],
	"colorSpecular" : [0.165, 0.165, 0.165],
	"illumination" : 2,
	"mapDiffuse" : "orig_02_-_Defaul1noCulling.JPG",
	"opticalDensity" : 1.0,
	"specularCoef" : 154.901961,
	"opacity" : 1.0
	},

	{
	"DbgColor" : 238,
	"DbgIndex" : 3,
	"DbgName" : "_01_-_Default1noCulli__01_-_Default1noCulli",
	"colorDiffuse" : [0.64, 0.64, 0.64],
	"colorSpecular" : [0.165, 0.165, 0.165],
	"illumination" : 2,
	"mapDiffuse" : "01_-_Default1noCulling.JPG",
	"opticalDensity" : 1.0,
	"specularCoef" : 154.901961,
	"opacity" : 1.0
	},

	{
	"DbgColor" : 15658496,
	"DbgIndex" : 4,
	"DbgName" : "FrontColorNoCullingID_male-02-1noCulling.JP",
	"colorDiffuse" : [0.8, 0.8, 0.8],
	"colorSpecular" : [0.165, 0.165, 0.165],
	"illumination" : 2,
	"mapDiffuse" : "male-02-1noCulling.JPG",
	"opticalDensity" : 1.0,
	"specularCoef" : 154.901961,
	"opacity" : 1.0
	}],

    "buffers": "Male02_bin.bin"

}
