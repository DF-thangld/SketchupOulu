Model by Reallusion iClone from Google 3d Warehouse:

http://sketchup.google.com/3dwarehouse/details?mid=f526cc4abf7cb68d76cab47c765b7255